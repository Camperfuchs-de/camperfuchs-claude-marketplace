---
name: camperfuchs-verfuegbarkeits-flow
description: Betrieb, Änderung und Troubleshooting des Camperfuchs Vermieter-Verfügbarkeits-Flows (Make-Szenarien 5482694 + 6030776, live seit 04.06.2026) — Verfügbarkeits-Mail mit JA/NEIN/Rückfrage-Buttons + Info-Buttons (Fahrzeug ansehen / anrufen), zweistufige Bestätigung gegen Scanner-Fehlklicks, automatischer Gmail-Entwurf an Mietinteressenten bei NEIN, Antwort-Tracking im Datastore + Live-Dashboard. Diese Skill IMMER nutzen bei Fragen rund um den Flow — explizit ('Verfügbarkeits-Mail ändern', 'Template anpassen', 'Vermieter-Buttons', 'Fahrzeug-Link/Telefon als Button', 'Bestätigungs-Seite', 'Antwort-Tracking', 'Verfügbarkeits-Dashboard', 'Szenario 5482694/6030776', 'Mieter-Entwurf bei Nein') ebenso wie implizit ('Vermieter sagt er hat geklickt aber nichts passiert', 'doppelte Antworten von einem Vermieter', 'Kunde hat keine Antwort bekommen', 'wer hat nicht reagiert', 'Mail-Design anpassen'). Enthält System-Landkarte (alle IDs), Test-Rezepte und teuer gelernte Gotchas.
---

# Camperfuchs Verfügbarkeits-Flow (Vermieter-Buttons + Tracking)

Arbeitsweise (chirurgische Blueprint-Edits, validate vor update, Sandbox erreicht make.com NICHT) steht in `camperfuchs-make` — die gilt hier immer mit.

## System-Landkarte (Stand 08.06.2026)

**Flow:** Neue Mietanfrage (Mail von noreply@) → **5482694 „Integration Gmail"** schickt dem Vermieter die Verfügbarkeits-Mail mit 3 Antwort-Button-Links + 2 Info-Buttons + loggt `status=offen` → Klick landet bei **6030776 „Vermieter Verfügbarkeit – Button-Antworten"** (Webhook `3164869`, URL `https://hook.eu1.make.com/tu2xumx8rhjynvul6l2stjxq7r5mcc55`).

**6030776 ist ZWEISTUFIG** (Scanner-Schutz, seit 04.06. ~20 Uhr):
- ohne `confirm`-Param → Router 11/Modul 12: nur Bestätigungs-Seite (2 Ops, KEINE Aktionen). Button dort ruft dieselbe URL mit `confirm=1` + allen Params re-encoded auf.
- mit `confirm=1` → Modul 2 Danke-Seite → Modul 13 UpdateRecord (Tracking) → Modul 8 DeleteRecord (24h-Reminder-Stopp, Datastore 124997) → Router 3:
  - **NEIN**: Modul 4 Kalender-Erinnerung an Vermieter (mit Backend-Button → `www.camperfuchs.de/backend/`) + Modul 5 Info an Björn + **Modul 10 Gmail-ENTWURF an den Mietinteressenten** (Betreff „Deine Wohnmobil-Anfrage bei Camperfuchs", personalisiert mit `{{1.vorname}}`, volle Signatur — Vorlage: `04_Setup-Anleitungen/Gmail-Signatur-Vorlage.html`)
  - **JA / Rückfrage**: Info-Mail an Björn

**Webhook-Params:** `aktion` (ja|nein|rueckfrage), `vermieter`, `betreff`, `mieter` (Mieter-E-Mail), `vorname`, `confirm`.

**Tracking:** Datastore **131528** „Verfügbarkeits-Tracking" (Struktur 444568), Key = `vermieter|betreff`. Felder: vermieter, kunde, fahrzeug, zeitraum, mieter, betreff, status (offen|ja|nein|rueckfrage), gesendet, beantwortet. 5482694 schreibt AddRecord (overwrite, onerror Ignore); 6030776 Confirm-Route UpdateRecord (Teilupdate, onerror Ignore). „offen" = nie bestätigt geklickt.

**Dashboard:** Cowork-Artefakt `verfuegbarkeits-antworten` — liest Datastore live via Make-MCP `data-store-records_list` (dataStoreId 131528). Zwei Tabs: Anfragen (KPIs + Filter-Tabelle) und Vermieter (pro Vermieter: Anfragen, JA/NEIN/Rückfrage/Offen, Antwortquote, Ø Reaktionszeit). Ändern via `update_artifact`.

**Design (von new.camperfuchs.de, Kadence-Palette):** weißer Header mit Badge-Logo `www.camperfuchs.de/wp-content/uploads/2026/06/CF_Logo_Badge_320x280.png` (Media-ID 19625), Titel-Band Braun `#89521f` weiß UPPERCASE, Datenblock Beige `#efeae6` (Kunde, Fahrzeug, Reisezeitraum, Bemerkung), darunter **2 braune Info-Buttons `#89521f`** („Fahrzeug ansehen" / „{{telefon}} anrufen", OHNE Emoji-Icons — Björn-Wunsch 08.06.), Text Anthrazit `#28383d`/`#484745`, dunkler Footer `#202020` mit weißem Logo `…/CF_Logo_Header_White.png` (ID 19626), Antwort-Buttons JA `#2e7d32` / NEIN `#c62828` / Rückfrage weiß mit Braun-Outline. Referenz-HTML: `01_Architektur-Tech/Vermieter-Verfuegbarkeitsmail_Buttons_2026-06-08_Vorschau.html` (älter: `…/Entwurf_Vermieter-Templates_NewDesign_2026-06-04.html`).

**Connections:** Gmail v4 `6998308` (Trigger, sendAnEmail, createADraft) · Google Restricted `7458024` (ActionSendEmail v2).

## Regex in 5482694 (Modul 7)

Parst aus der Anfrage-Mail: fahrzeug, zeitraum, vorname, nachname, **email** (`E-mail: (?<email>\S+)` — exakt diese Schreibweise im Mail-Template!), telefon, bemerkung. Bei neuen Feldern: Regex erweitern + `metadata.interface` ergänzen + Button-URLs (`&mieter=…&vorname=…`-Muster) + ggf. Bestätigungs-Seiten-URL in 6030776 Modul 12 nachziehen — alle drei Stellen, sonst kommt das Feld nicht durch.

**Wichtig — Regex NICHT für jede Kleinigkeit anfassen:** Der Parser (`continueWhenNoRes:true`) liefert bei Nicht-Match LEERE Felder → Verfügbarkeits-Mail geht mit leeren Werten raus an einen echten Partner. Wenn ein neuer Wert nur aus einem schon geparsten Feld ableitbar ist (siehe Fahrzeug-URL unten), lieber im **Mapper** extrahieren statt den Live-Regex umzuschreiben.

## Fahrzeug-Link & Telefon als Buttons (M2, seit 08.06.2026)

`{{7.fahrzeug}}` kommt im Plain-Text-Link-Format **„Name [URL]"** (z.B. `Kulba Rebell x-Line [https://email.mg.camperfuchs.de/c/…]`). camperfuchs.com-Partner-Mails haben die `[URL]`, manche Fremd-Partner-Mails NUR den Namen (ohne Bracket). URL OHNE Regex-Änderung direkt im Mapper ziehen (kein Parser-Risiko):

- **Fahrzeugname (Anzeige, ohne Roh-URL):** `{{trim(first(split(7.fahrzeug; "[")))}}`
- **Fahrzeug-URL (Button-href):** `{{if(contains(7.fahrzeug; "["); trim(replace(last(split(7.fahrzeug; "[")); "]"; "")); "https://www.camperfuchs.de")}}` — Fallback Homepage, wenn keine `[URL]` da ist.
- **Telefon-Button:** `href="tel:{{7.telefon}}"`, Beschriftung `{{7.telefon}} anrufen`.

Die Semikolons in diesen Formeln sind Argument-Trenner; die String-Literale (`"["`, `"]"`, `""`, URL) enthalten selbst KEINE Semikolons → unkritisch (vgl. Gotcha unten: keine HTML-Blöcke mit `;` in if()). Make speichert die IML 1:1 (zurückgelesen, `isinvalid:false`). Runtime-Funktionen (`split/first/last/trim/replace/contains/if`) sind Standard.

## Blueprint validieren + updaten (Schema-Falle)

`scenarios_get` liefert den Blueprint MIT top-level `scheduling` + `interface`. **`validate_blueprint_schema` lehnt beide als „additional properties" ab** → vor validate/update entfernen. Gültiger Blueprint = nur `{ name, flow, metadata }`. `scenarios_update` mit diesem Blueprint bewahrt Scheduling/Interface des Szenarios (separat gespeichert, nicht zurückgesetzt). Ablauf: `scenarios_get` → HTML im Mapper ändern → `scheduling`/`interface` strippen → `validate_blueprint_schema` → `scenarios_update` → `scenarios_get` zurücklesen (HTML/IML intakt? `isinvalid:false`?).

## Test-Rezept (immer mit vermieter=b.dunker@…, nie echte Partner)

1. **Stufe 1 (Scanner-Simulation):** Chrome-`navigate` auf Hook-URL mit `?aktion=nein&vermieter=b.dunker%40camperfuchs.de&betreff=TEST&mieter=b.dunker%40camperfuchs.de&vorname=Karolina` → `get_page_text` muss „ANTWORT BESTÄTIGEN" zeigen. `executions_list`: 2 Ops, KEINE Mails.
2. **Stufe 2:** gleiche URL + `&confirm=1` → Danke-Seite, 6 Ops, in Björns Postfach: Kalender-Erinnerung + Info-Mail + Mieter-Entwurf; `data-store-records_list` (131528): Record auf `nein` + beantwortet gesetzt.
3. Testdaten danach aufräumen: Record löschen (`data-store-records_delete`), Test-Mails/Entwurf löschen lassen.

**Mail-Render von 5482694 (M2) ist NICHT sicher selbst testbar** — ein echter Lauf würde die Verfügbarkeits-Mail an `{{1.to[1].address}}` = einen echten Vermieter schicken. Daher: HTML offline mit Beispieldaten rendern (Vorschau via `show_widget`/Datei) + Blueprint zurücklesen, und die finale Live-Darstellung an der NÄCHSTEN echten Anfrage prüfen (`executions_list`). Blast-Radius bei IML-Fehler in den Info-Buttons ist klein (nur die 2 Buttons; JA/NEIN/Tracking unberührt).

## Gotchas (teuer gelernt)

- **Scanner-Prefetch ist REAL:** 04.06. 18:05 riefen Provider-Scanner 18 Sek nach Versand alle 3 Button-Links ab (5 Hits/11 Sek) → deshalb der Zwei-Stufen-Flow. NIE auf einstufig zurückbauen. Scanner folgen Mail-Links, klicken aber keine Buttons auf Seiten.
- **Gmail 451 „temporarily rejected"** beim ActionSendEmail kommt vor → temporär, Execution ist replayable, einfach erneut auslösen.
- **`switch()`/`if()` in Mappern:** String-Argumente in doppelten Anführungszeichen; KEINE Semikolons in den Strings (Semikolon = Argument-Trenner). Große HTML-Blöcke nie in Formeln stecken (deshalb wird die Fahrzeug-URL extrahiert und nur als kleiner href-Wert per if() gesetzt, nicht der ganze Button im if()).
- **Filter auf leere Webhook-Params:** `exist` reicht NICHT (leerer String existiert) → `text:notequal ""` verwenden (so beim Mieter-Entwurf Modul 10).
- **Datastore-Teilupdate** = `datastore:UpdateRecord`; `AddRecord` mit overwrite ERSETZT den ganzen Record.
- **Mieter-Entwurf ist bewusst OHNE Design-Template** — soll wie eine persönlich von Björn geschriebene Mail wirken (htmlBody + volle Signatur in Braun #783f04). Textregeln: Du-Form, kein Druck/Verknappung, NIE Reservierung anbieten, keine Telefon-CTAs (siehe camperfuchs-brand + Memory-Feedback).
- **Logos von www. laden** (nicht new. — Subdomain verschwindet beim Relaunch). Neue Bilder per WP-REST-API hochladen (Zugang: `.secrets/Claude AP-wordpressI.txt` Zeile 3, User bjoerndunker).
- **Betreff-Kollision im Tracking:** Key `vermieter|betreff` — fragt derselbe Kunde dasselbe Fahrzeug erneut an, überschreibt der neue Versand den alten Record (gewollt: letzte Anfrage zählt).
- Alt-Mails (vor 04.06. abends versendet) haben keine `mieter`/`vorname`-Params → Filter überspringen Entwurf einfach; kein Fehler.

## Typische Aufgaben

- **Template-Text/Design ändern:** Blueprint per `scenarios_get` ziehen, NUR den HTML-String im betreffenden Mapper ändern (5482694 M2 = Verfügbarkeits-Mail; 6030776 M12 = Bestätigungs-Seite, M2 = Danke-Seite, M4 = Kalender-Erinnerung, M10 = Mieter-Entwurf), `scheduling`/`interface` strippen, validate, update, zurücklesen, Test-Rezept fahren, Referenz-HTML im Projektordner nachziehen.
- **Fahrzeug-/Telefon-Button ändern:** nur Modul 2 (Mapper `html`) — Beschriftung/Style der `<a>`-Buttons bzw. die Extraktions-IML (siehe Abschnitt „Fahrzeug-Link & Telefon als Buttons").
- **Wer hat nicht reagiert / Quote:** Dashboard-Artefakt öffnen (Tab „Vermieter") oder ad hoc `data-store-records_list` auswerten.
- **Dashboard erweitern:** HTML neu schreiben → `update_artifact` (id `verfuegbarkeits-antworten`). Datenform: Array von `{key, data:{…}}`.
