---
name: camperfuchs-verfuegbarkeits-flow
description: Betrieb, Änderung und Troubleshooting des Camperfuchs Vermieter-Verfügbarkeits-Flows (Make-Szenarien 5482694 + 6030776, live seit 04.06.2026) — Verfügbarkeits-Mail mit JA/NEIN/Rückfrage-Buttons + Info-Buttons (Fahrzeug ansehen / anrufen), zweistufige Bestätigung gegen Scanner-Fehlklicks, automatischer Gmail-Entwurf an Mietinteressenten bei NEIN (optional mit Alternativ-Zeitraum/-Fahrzeug), Antwort-Tracking im Datastore + Live-Dashboard. Diese Skill IMMER nutzen bei Fragen rund um den Flow — explizit ('Verfügbarkeits-Mail ändern', 'Template anpassen', 'Vermieter-Buttons', 'Bestätigungs-Seite', 'Antwort-Tracking', 'Szenario 5482694/6030776', 'Mieter-Entwurf bei Nein', 'Alternative anbieten') ebenso wie implizit ('Vermieter sagt er hat geklickt aber nichts passiert', 'doppelte Antworten von einem Vermieter', 'Kunde hat keine Antwort bekommen', 'wer hat nicht reagiert', 'Mail-Design anpassen'). Enthält System-Landkarte (alle IDs), Test-Rezepte und teuer gelernte Gotchas.
---

# Camperfuchs Verfügbarkeits-Flow (Vermieter-Buttons + Tracking)

Arbeitsweise (chirurgische Blueprint-Edits, validate vor update) steht in `camperfuchs-make` — die gilt hier immer mit. ⚠️ Korrektur 15.06.: der Make-**Hook** `hook.eu1.make.com/…` IST aus der Sandbox per `curl` erreichbar (siehe Test-Rezept), auch wenn die make.com-**App/API** es nicht ist.

## System-Landkarte (Stand 15.06.2026)

**Flow:** Neue Mietanfrage (Mail von noreply@) → **5482694 „Integration Gmail"** schickt dem Vermieter die Verfügbarkeits-Mail mit 3 Antwort-Button-Links + 2 Info-Buttons + loggt `status=offen` → Klick landet bei **6030776 „Vermieter Verfügbarkeit – Button-Antworten"** (Webhook `3164869`, URL `https://hook.eu1.make.com/tu2xumx8rhjynvul6l2stjxq7r5mcc55`).

**6030776 ist ZWEISTUFIG** (Scanner-Schutz, seit 04.06. ~20 Uhr; Router 11 hat seit 15.06. DREI Routen):
- ohne `confirm`-Param: bei **NEIN → Modul 20 Formular-Seite** (zwei OPTIONALE Freitextfelder „Alternativer Zeitraum" / „Alternatives Fahrzeug"); bei **JA/Rückfrage → Modul 12 Button-Seite**. Beide rufen dieselbe URL mit `confirm=1` + allen Params (+ ggf. `alt_zeitraum`/`alt_fahrzeug` aus dem Formular) auf. Filter: Modul 12 = `confirm notexist` UND `aktion text:notequal nein`; Modul 20 = `confirm notexist` UND `aktion text:equal nein`.
- mit `confirm=1` → Modul 2 Danke-Seite → Modul 17 AddRecord (geklickt) → Modul 13 UpdateRecord (Tracking) → Modul 8 DeleteRecord (24h-Reminder-Stopp, Datastore 124997) → Router 3:
  - **NEIN**: Modul 4 Kalender-Erinnerung an Vermieter (Backend-Button → `www.camperfuchs.de/backend/`) + Modul 5 Info an Björn (zeigt Alternativ-Zeitraum/-Fahrzeug im Beige-Block) + **Modul 10 Gmail-ENTWURF an den Mietinteressenten** (Betreff „Deine Wohnmobil-Anfrage bei Camperfuchs", personalisiert mit `{{1.vorname}}`, volle Signatur, **conditional Alternativ-Absatz** — Vorlage: `04_Setup-Anleitungen/Gmail-Signatur-Vorlage.html`)
  - **JA / Rückfrage**: Info-Mail an Björn

**Webhook-Params:** `aktion` (ja|nein|rueckfrage), `vermieter`, `betreff`, `mieter` (Mieter-E-Mail), `vorname`, `confirm`, **`alt_zeitraum`/`alt_fahrzeug`** (optional, nur aus dem NEIN-Formular Modul 20).

**Tracking:** Datastore **131528** „Verfügbarkeits-Tracking" (Struktur 444568), Key = `vermieter|betreff`. Felder: vermieter, kunde, fahrzeug, zeitraum, mieter, betreff, status (offen|ja|nein|rueckfrage), gesendet, beantwortet. 5482694 schreibt AddRecord (overwrite, onerror Ignore); 6030776 Confirm-Route UpdateRecord (Teilupdate, onerror Ignore). „offen" = nie bestätigt geklickt. (Zweiter „geklickt"-Datastore **131793**, Key `vermieter|betreff|aktion`.)

**Dashboard:** Cowork-Artefakt `verfuegbarkeits-antworten` — liest Datastore live via Make-MCP `data-store-records_list` (dataStoreId 131528). Zwei Tabs: Anfragen (KPIs + Filter-Tabelle) und Vermieter (pro Vermieter: Anfragen, JA/NEIN/Rückfrage/Offen, Antwortquote, Ø Reaktionszeit). Ändern via `update_artifact`.

**Design (von new.camperfuchs.de, Kadence-Palette):** weißer Header mit Badge-Logo `www.camperfuchs.de/wp-content/uploads/2026/06/CF_Logo_Badge_320x280.png` (Media-ID 19625), Titel-Band Braun `#89521f` weiß UPPERCASE, Datenblock Beige `#efeae6` (Kunde, Fahrzeug, Reisezeitraum, Bemerkung), darunter **2 braune Info-Buttons `#89521f`** („Fahrzeug ansehen" / „{{telefon}} anrufen", OHNE Emoji-Icons — Björn-Wunsch 08.06.), Text Anthrazit `#28383d`/`#484745`, dunkler Footer `#202020` mit weißem Logo `…/CF_Logo_Header_White.png` (ID 19626), Antwort-Buttons JA `#2e7d32` / NEIN `#c62828` / Rückfrage weiß mit Braun-Outline. Formular-Seite (Modul 20) übernimmt dieselbe Palette. Referenz-HTML: `01_Architektur-Tech/Vermieter-Verfuegbarkeitsmail_Buttons_2026-06-08_Vorschau.html`, `01_Architektur-Tech/Verfuegbarkeit-NEIN-Formular_2026-06-15_Vorschau.html`.

**Connections:** Gmail v4 `6998308` (Trigger, sendAnEmail, createADraft) · Google Restricted `7458024` (ActionSendEmail v2).

## Regex in 5482694 (Modul 7)

Parst aus der Anfrage-Mail: fahrzeug, zeitraum, vorname, nachname, **email** (`E-mail: (?<email>\S+)` — exakt diese Schreibweise im Mail-Template!), telefon, bemerkung. Bei neuen Feldern: Regex erweitern + `metadata.interface` ergänzen + Button-URLs (`&mieter=…&vorname=…`-Muster) + ggf. Bestätigungs-Seiten-URL in 6030776 nachziehen — alle drei Stellen, sonst kommt das Feld nicht durch.

**Wichtig — Regex NICHT für jede Kleinigkeit anfassen:** Der Parser (`continueWhenNoRes:true`) liefert bei Nicht-Match LEERE Felder → Verfügbarkeits-Mail geht mit leeren Werten raus an einen echten Partner. Wenn ein neuer Wert nur aus einem schon geparsten Feld ableitbar ist (siehe Fahrzeug-URL unten), lieber im **Mapper** extrahieren statt den Live-Regex umzuschreiben.

## Fahrzeug-Link & Telefon als Buttons (M2, seit 08.06.2026)

`{{7.fahrzeug}}` kommt im Plain-Text-Link-Format **„Name [URL]"** (z.B. `Kulba Rebell x-Line [https://email.mg.camperfuchs.de/c/…]`). camperfuchs.com-Partner-Mails haben die `[URL]`, manche Fremd-Partner-Mails NUR den Namen (ohne Bracket). URL OHNE Regex-Änderung direkt im Mapper ziehen (kein Parser-Risiko):

- **Fahrzeugname (Anzeige, ohne Roh-URL):** `{{trim(first(split(7.fahrzeug; "[")))}}`
- **Fahrzeug-URL (Button-href):** `{{if(contains(7.fahrzeug; "["); trim(replace(last(split(7.fahrzeug; "[")); "]"; "")); "https://www.camperfuchs.de")}}` — Fallback Homepage, wenn keine `[URL]` da ist.
- **Telefon-Button:** `href="tel:{{7.telefon}}"`, Beschriftung `{{7.telefon}} anrufen`.

Die Semikolons in diesen Formeln sind Argument-Trenner; die String-Literale (`"["`, `"]"`, `""`, URL) enthalten selbst KEINE Semikolons → unkritisch (vgl. Gotcha unten: keine HTML-Blöcke mit `;` in if()). Make speichert die IML 1:1 (zurückgelesen, `isinvalid:false`). Runtime-Funktionen (`split/first/last/trim/replace/contains/if`) sind Standard.

## NEIN-Alternative (Route 20 Formular + conditional Entwurf, seit 15.06.2026)

Klickt der Vermieter NEIN, kommt statt der reinen Bestätigung **Modul 20** = Formular-Seite mit zwei OPTIONALEN Freitextfeldern als `<form method=get>` zurück an den eigenen Hook (`confirm=1&aktion=nein` + Hidden-Felder vermieter/betreff/mieter/vorname + die Eingaben `alt_zeitraum`/`alt_fahrzeug`). Leer lassen = Absage exakt wie früher. Scanner-sicher, weil Formular-Submit ein Page-Button ist (kein Mail-Link).

**Modul 10 Kunden-Entwurf** baut die Alternative über zwei `if()`-Fragmente ein (Make-Truthiness: leerer String = falsy → kein hängender Satz):
`{{if(1.alt_fahrzeug; " Der Vermieter hätte zum Beispiel dieses Fahrzeug frei: " + 1.alt_fahrzeug + "."; "")}}{{if(1.alt_zeitraum; " Ein möglicher Zeitraum wäre: " + 1.alt_zeitraum + "."; "")}}` — eingebettet im Basissatz „Die gute Nachricht: Oft finden wir eine passende Alternative für dich. … Sag uns einfach kurz, wie flexibel du bist …". **Bleibt Entwurf** → Björn ergänzt bei Bedarf den Fahrzeug-Deeplink (siehe `camperfuchs-alternativ-angebot`).

**Variante B (Vermieter tippt seine EIGENEN freien Fahrzeuge an) bewusst NICHT umgesetzt:** die öffentliche `/api/V1/articles` kennt keinen Vermieter (nur `location` + lat/long) und der NEIN-Button trägt die Fahrzeug-URL nicht mit → braucht einen Vermieter→Fahrzeuge-Backend-Endpoint (Bahti). Bis dahin Freitext (A).

## Blueprint validieren + updaten (Schema-Falle)

`scenarios_get` liefert den Blueprint MIT top-level `scheduling` + `interface`. **`validate_blueprint_schema` lehnt beide als „additional properties" ab** → vor validate/update entfernen. Gültiger Blueprint = nur `{ name, flow, metadata }`. `scenarios_update` mit diesem Blueprint bewahrt Scheduling/Interface des Szenarios (separat gespeichert, nicht zurückgesetzt). Ablauf: `scenarios_get` → HTML/IML im Mapper ändern → `scheduling`/`interface` strippen → `validate_blueprint_schema` → `scenarios_update` → `scenarios_get` zurücklesen (HTML/IML intakt? `isinvalid:false`?). ⚠️ **Riesige Mapper-Strings (Signatur in M10!) NIEMALS von Hand neu tippen** — beim manuellen Re-Emit ein Bild-Token abgeschnitten (15.06.). Stattdessen Original sichern, Edits per Python auf den Rohtext (kurze Anker), valides JSON erzeugen, danach Live-Reread + alle opaken Tokens (mail-sig/streak-Links) gegenprüfen.

## Test-Rezept (immer mit vermieter=b.dunker@…, nie echte Partner)

**Headless per Sandbox-curl (15.06. erprobt, kein Chrome nötig):**
1. **Stufe 1 (NEIN, Scanner-Simulation):** `curl "https://hook.eu1.make.com/tu2xumx8rhjynvul6l2stjxq7r5mcc55?aktion=nein&vermieter=b.dunker%40camperfuchs.de&betreff=TEST&mieter=b.dunker%40camperfuchs.de&vorname=Karolina"` → muss die **Formular-Seite** (zwei Felder) liefern, keine Aktion. (JA/Rückfrage → Button-Seite.)
2. **Stufe 2 (Formular-Submit):** `curl -G …/tu2… --data-urlencode confirm=1 --data-urlencode aktion=nein --data-urlencode vermieter=b.dunker@… --data-urlencode betreff=TEST --data-urlencode mieter=b.dunker@… --data-urlencode vorname=Karolina --data-urlencode "alt_zeitraum=2. – 9. August" --data-urlencode "alt_fahrzeug=Kulba Rebell"` → Danke-Seite; in Björns Postfach Kalender-/Info-Mail + **Mieter-Entwurf**.
3. **Entwurf prüfen** per Gmail-MCP `list_drafts` (query `subject:"Deine Wohnmobil-Anfrage bei Camperfuchs"`) → `get_thread` (FULL_CONTENT): Alternativ-Absatz korrekt? Auch den **Leer-Fall** (alt-Felder leer) testen → Absatz ohne hängende Satzteile.
4. Aufräumen: Test-Records löschen (`data-store-records_delete` DS 131793 Key `vermieter|betreff|nein`, DS 131528 Key `vermieter|betreff`); Test-Mails/Entwürfe von Björn lösche